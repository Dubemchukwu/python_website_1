from flet import *
import flet
import requests

url = "https://dubemguy.pythonanywhere.com/led/api"


class LedButton(IconButton):
    def __init__(self, color: str, name: str, data: str):
        super().__init__()
        self.__color = color
        self.__name = name
        self.bgcolor = colors.TRANSPARENT
        self.content = Container(bgcolor=self.__color, width=50, height=50, shape=BoxShape.CIRCLE,
                                 animate=animation.Animation(1500, animation.AnimationCurve.ELASTIC_IN_OUT),
                                 animate_scale=animation.Animation(1500, animation.AnimationCurve.ELASTIC_IN_OUT),
                                 scale=1, on_animation_end=self.__end_light_animation)
        self.icon_size = 50
        self.icon_color = self.__color
        self.selected = False
        self.data = data
        self.animate = animation.Animation(1500, animation.AnimationCurve.ELASTIC_IN_OUT)
        self.scale = 1
        self.animate_scale = animation.Animation(1500, animation.AnimationCurve.ELASTIC_IN_OUT)
        self.on_click = self.__action_led

    def __end_light_animation(self, e):
        e.control.scale = 1
        e.control.update()

    def __action_led(self, e: ControlEvent):
        if not e.control.selected:
            e.control.selected = True
            data = e.control.data + "on"
            requests.put(url, json={"serial": data})
            e.control.content.scale = 1.5
        else:
            e.control.selected = False
            data = e.control.data + "off"
            requests.put(url, json={"serial": data})
            e.control.content.scale = 1.5
        e.control.update()


class SpecialButton(ElevatedButton):
    def __init__(self, name: str, data):
        super().__init__()
        self.content = Text(value=name, font_family="JetBrains Mono", size=23, color=colors.BLUE_GREY_500)
        self.data = data
        self.width = 230
        self.height = 60
        self.elevation = 20
        self.on_click = self.__do_job
        self.style = ButtonStyle(shape=RoundedRectangleBorder(radius=12), bgcolor=colors.TRANSPARENT,
                                 elevation=19, shadow_color="black12")

    def __do_job(self, e):
        requests.put(url, json={"serial": e.control.data}).json()


class Arduino:

    def __init__(self, serve):
        self.__serve = serve
        self.__run()

    def __main(self, screen: Page):
        screen.title = "Arduino Light control App"
        screen.vertical_alignment = MainAxisAlignment.START
        screen.horizontal_alignment = CrossAxisAlignment.CENTER

        def __resize(e: WindowEvent):
            e.page.controls[0].height = e.page.height - 30
            e.page.controls[0].update()
            print(e.page.height)

        screen.window.on_event = __resize

        screen.add(
            Column(
                horizontal_alignment=CrossAxisAlignment.CENTER,
                height=screen.height - 70,
                alignment=MainAxisAlignment.SPACE_BETWEEN,
                controls=[
                    Column(
                        alignment=MainAxisAlignment.START,
                        spacing=20,
                        horizontal_alignment=CrossAxisAlignment.CENTER,
                        controls=[
                            LedButton(color=colors.BLUE, name="blue", data="led5"),
                            Row(
                                alignment=MainAxisAlignment.SPACE_EVENLY,
                                vertical_alignment=CrossAxisAlignment.CENTER,
                                controls=[
                                    LedButton(color=colors.WHITE, name="white", data="led1"),
                                    LedButton(color=colors.RED, name="red", data="led2"),
                                ],
                            ),
                            Row(
                                alignment=MainAxisAlignment.SPACE_EVENLY,
                                vertical_alignment=CrossAxisAlignment.CENTER,
                                controls=[
                                    LedButton(color=colors.GREEN, name="green", data="led3"),
                                    LedButton(color=colors.YELLOW, name="yellow", data="led4"),
                                ],
                            ),
                        ],
                    ),
                    Row(
                        alignment=MainAxisAlignment.SPACE_EVENLY,
                        vertical_alignment=CrossAxisAlignment.START,
                        controls=[
                            SpecialButton(name="Turn on all", data="ledallon"),
                            SpecialButton(name="Turn off all", data="ledalloff"),
                        ],
                    ),
                    Row(
                        alignment=MainAxisAlignment.CENTER,
                        controls=[OutlinedButton(width=400, height=50, icon_color="black54",
                                                 style=ButtonStyle(shape=RoundedRectangleBorder(10),
                                                                   overlay_color=colors.TRANSPARENT,
                                                                   shadow_color=colors.TRANSPARENT,
                                                                   side=BorderSide(1, colors.BLUE_GREY_500)),
                                                 content=Text(value="Special Functions", size=25,
                                                              font_family="JetBrains Mono",
                                                              color=colors.BLUE_GREY_500)), ]
                    ),
                    Column(
                        alignment=MainAxisAlignment.START,
                        run_spacing=10, spacing=10,
                        horizontal_alignment=CrossAxisAlignment.CENTER,
                        controls=[
                            SpecialButton(name="Police", data="police"),
                            SpecialButton(name="Special", data="special1"),
                            SpecialButton(name="Game", data="random"),
                            SpecialButton(name="Ambulance", data="ambulance"),
                        ],
                    ),
                ],
            ),
        )
        screen.update()

    def __run(self):
        self.__serve.app(target=self.__main, port=3000, view=AppView.WEB_BROWSER, use_color_emoji=True,
                         web_renderer=WebRenderer.HTML, route_url_strategy="HASH")


Arduino(flet)
